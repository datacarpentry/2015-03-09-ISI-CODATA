#Data Carpentry data

This directory contains the datasets used as examples for the lessons in the datacarpentry/lessons directory. Here is a list of the subdirectories and contents.

##biology

Example data from the biological sciences.

### aphid data

**Publication**: Bahlai, C.A., Schaafsma, A.W., Lagos, D., Voegtlin, D., Smith, J.L., Welsman, J.A., Xue, Y., DiFonzo, C., Hallett, R.H., 2014. Factors inducing migratory forms of soybean aphid and an examination of North American spatial dynamics of this species in the context of migratory behavior. Agriculture and Forest Entomology. 16, 240-250 http://dx.doi.org/10.1111/afe.12051

**Downloaded from**: http://lter.kbs.msu.edu/datatables/122

**Used in**: Excel lessons (datacarpentry/lessons/excel/ecology-examples)

**Files**

* Master_suction_trap_data_list_uncleaned.csv : a pre-cleaning version of the dataset
* aphid_data_Bahlai_2014.xlsx : spreadsheet with aphid data

### Portal mammals data

This is data on a small mammal community in southern Arizona over the last 35 years. This is part of a larger project studying the effects of rodents and ants on the plant community. The rodents are sampled on a series of 24 plots, with different experimental manipulations of which rodents are allowed to access the plots.

**Publication**: S. K. Morgan Ernest, Thomas J. Valone, and James H. Brown. 2009. Long-term monitoring and experimental manipulation of a Chihuahuan Desert ecosystem near Portal, Arizona, USA. Ecology 90:1708.

**Downloaded from:** [http://esapubs.org/archive/ecol/E090/118/]()

**Used in:** excel, shell, R, python and SQL lessons

**Files**

* plots.csv : a list of the experimental plot IDs and descriptions
* species.csv : a list of the two-letter species code and information about the species
* surveys.csv : the full list of observations of species on plots
* surveys-exercise-extract_month.csv : a small  subset of the surveys data used in one of the excel lessons
* portal_mammals.sqlite : a SQLite database of the mammal data; incorporates plots.csv, species.csv and surveys.csv
